//: Playground - noun: a place where people can play

import Foundation

/**************************************************************************************************
** PASS FUNCTION TO ANOTHER FUNCTION
**************************************************************************************************/
func add(num1: Double, num2: Double) -> Double {
	return num1 + num2
}

func diff(num1: Double, num2: Double) -> Double {
	return num1 - num2
}


func doMathOperation(operation:(_ x: Double, _ y: Double) -> Double, num1: Double, num2: Double) -> Double {
	return operation(num1, num2)
}

let result = doMathOperation(operation: add, num1: 5, num2: 4)
print("✡️ HIGHER ORDER FUNCTIONS - \(result)")

/**************************************************************************************************
** RETURN A FUNCTION FROM ANOTHER FUNCTION
**************************************************************************************************/
func doArithmeticOperation(add: Bool) -> (Double, Double) -> Double {
	func addNumbers(num1: Double, num2: Double) -> Double {
		return num1 + num2
	}
	func diffNumbers(num1: Double, num2: Double) -> Double {
		return num1 - num2
	}
	return add ? addNumbers : diffNumbers
}

let operation1 = doArithmeticOperation(add: true)
let operation2 = doArithmeticOperation(add: false)

let result1 = operation1(5,5)
let result2 = operation2(5,5)
print("✡️ RETURN A FUNCTION FROM ANOTHER FUNCTION - \(result1), \(result2) ")

/**************************************************************************************************
** MAP - Used to apply some operation on each item in an array or dictionary
**************************************************************************************************/
let array = [10,20,63,12,13,55]
let newArray = array.map({ $0 * 10 })
print("✡️ MAP ON ARRAY - \(newArray) ")

let dict = ["HP": 100, "LOTR": 200]
let newDict = dict.map{(key, value) in
	return key.capitalized
}
print("✡️ MAP ON DICT - \(newDict) ")

/**************************************************************************************************
** FILTER - Used to filter out items from an arry or dictionary based on a condition
**************************************************************************************************/
let numArray = [10,20,63,12,13,55]
let newNumArray = numArray.filter {$0%2 == 0}
print("✡️ FILTER ON ARRAY - \(newNumArray) ")

let bookDict = ["HP": 100, "LOTR": 200]
let newBookDict = bookDict.filter({$1>100})
print("✡️ FILTER ON DICT - \(newBookDict) ")

/**************************************************************************************************
** REDUCE - Used to combine all items into a single new value
**************************************************************************************************/
let numbers = [1,2,3,4]
let sum = numbers.reduce(0, { $0 + $1 })
print("✡️ SUM - \(sum) ")

let characters = ["r","e","s","h"]
let word = characters.reduce("One ", { $0 + $1 })
print("✡️ WORD - \(word) ")

let booksDict = ["HP": 100, "LOTR": 200]
let newBooksDict = bookDict.reduce(0, { $0 + $1.value})
print("✡️ REDUCE ON DICT - \(newBooksDict) ")

/**************************************************************************************************
** FLATMAP - Used to flatten a collection of collections
**************************************************************************************************/
let numArrayForFlapmap = [[1,2,3,4], [5,6]]
let newNumArrayForFlapmap = numArrayForFlapmap.flatMap{ $0 }
print("✡️ FLATMAP ON ARRAY - \(newNumArrayForFlapmap) ")

let booksDictForFlapmap = [["HP": 100, "LOTR": 200], ["DOET": 300, "CC": 400]]
let newBooksDictForFlapmap = booksDictForFlapmap.flatMap{ $0 }
var newDictForFlapmap = [String: Int]()
newBooksDictForFlapmap.forEach{
	newDictForFlapmap[$0.key] = $0.value
}
print("✡️ FLATMAP ON DICT - \(newDictForFlapmap) ")

/**************************************************************************************************
** Chaining multiple higher order functions
**************************************************************************************************/
//Let’s say we want to add the squares of all the even numbers from an array of arrays.

let arrayOfArrays = [[1,2,3,4],[5,6,7,8,9]]
// Combine arrays
let evenNumbers = arrayOfArrays.flatMap{ $0 }.filter{ $0%2 == 0 }
let sumOfAll = evenNumbers.map{ $0*$0 }.reduce(0, { $0 + $1 })
print("\n\n \(sumOfAll)")
